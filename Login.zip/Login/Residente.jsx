import React from 'react'

export const Residente = () => {
  return (
    <div>Residente</div>
  )
}
