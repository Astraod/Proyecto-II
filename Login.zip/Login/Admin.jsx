import React from 'react'

export const Admin = () => {
  return (
    <div>Admin</div>
  )
}
