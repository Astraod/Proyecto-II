import React, { useState } from 'react'
import los_robles_logo from './los_robles_logo.webp';
import { Admin } from './Admin';
import { Residente } from './Residente'
import './login.css';

export const Iniciar_sesion = () => {

  const [miLogin, setLogin] = useState("false");
  const [miLogin2, setLogin2] = useState("false");
  const [usuario, setUsuario] =useState("");
  const [password, setpassword] =useState("");

  function Iniciar(e){
    e.preventDefault();
    var username = document.getElementById("username").value;
    var pass = document.getElementById("password").value;

    if (username.length === 0 || pass.length === 0){
      alert("Complete los datos faltantes");
    } else {
      if (usuario === "admin" && password === "123"){
        setLogin("true");
        document.getElementById("intento").style.display = "none";
        } else {
          if (usuario === "user" && password === "456"){
            setLogin2("true");
            document.getElementById("intento").style.display = "none";
          } else {
          setLogin("false");
          alert("Error de usuario y/o contraseña");
          document.getElementById("username").value = "";
          document.getElementById("password").value = "";
          document.getElementById("username").focus();
        }
      }
    }
  }

  return (
    <div>
      <div className="login" >
        <div className="login__container" id='intento'>
          <img src={los_robles_logo} alt="Los Robles Logo" className="login__logo" />

          <form className="login__form">
            <label htmlFor="username">Nombre</label>
            <input className="login__form__input" placeholder="Escribe tu Nombre aquí" type="text" id="username" onChange={(e)=>setUsuario(e.target.value)} required/>

            <label htmlFor="password">Contraseña</label>
            <input className="login__form__input" placeholder="Escribe tu Contraseña aquí" type="password" id="password" onChange={(e)=>setpassword(e.target.value)} required/>

            <input type="submit" className="login__button" value="Iniciar" onClick={ Iniciar }/>
          </form>
          
        </div>
        
        { miLogin === "true" && <Admin/> }
        { miLogin2 === "true" && <Residente/> }
      </div>
    </div>
     
    
  )
}
